import background from './background.png'

const Pic = ()=>{
    return(
        <div>
        <img src = {background} alt='img' style = {{width : '1450px'}}/>
        </div>
    )
}
export default Pic;