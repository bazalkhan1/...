const pass =  [
    {
        name : "bazal",
        pass : "bazal123"
    }

]
export default pass;